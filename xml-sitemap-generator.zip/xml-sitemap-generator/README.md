
# XML Sitemap Generator for Google (Simple)

Lightweight WordPress plugin to generate XML sitemap with one click.

## ✅ Features
- One click sitemap generation
- Supports posts and pages
- Lightweight & fast
- Compatible with latest WordPress versions
- SEO friendly XML sitemap

## 🚀 Installation
1. Download the plugin zip
2. Go to WordPress → Plugins → Add New → Upload Plugin
3. Upload zip and activate
4. Go to **XML Sitemap** menu
5. Click **Generate Sitemap**

## 📌 SEO Benefits
- Helps Google index pages faster
- Improves crawl efficiency
- Works with Google Search Console
- Clean XML format

## 📂 Plugin Structure
```
xml-sitemap-generator/
 └── xml-sitemap-generator.php
```

## 👨‍💻 Author
Nimbyist Technologies

## 📄 License
GPL v2 or later
