<?php
/*
Plugin Name: XML Sitemap Generator for Google (Simple)
Description: One click XML Sitemap Generator for Google. Compatible with all WordPress versions.
Version: 1.0
Author: Nimbyist Technologies
*/

if (!defined('ABSPATH')) exit;

/* Admin Menu */
add_action('admin_menu', function () {
    add_menu_page(
        'XML Sitemap Generator',
        'XML Sitemap',
        'manage_options',
        'xml-sitemap-generator',
        'xsg_admin_page',
        'dashicons-networking'
    );
});

/* Admin Page */
function xsg_admin_page() {
    ?>
    <div class="wrap">
        <h1>XML Sitemap Generator</h1>

        <form method="post">
            <?php wp_nonce_field('xsg_generate'); ?>
            <input type="submit" name="xsg_generate_btn" class="button button-primary" value="Generate Sitemap">
        </form>

        <?php
        if (isset($_POST['xsg_generate_btn']) && check_admin_referer('xsg_generate')) {
            xsg_generate_sitemap();
            echo '<div class="updated"><p>Sitemap generated successfully.</p></div>';
        }
        ?>
    </div>
    <?php
}

/* Generate Sitemap */
function xsg_generate_sitemap() {

    $posts = get_posts([
        'numberposts' => -1,
        'post_type' => ['post','page'],
        'post_status' => 'publish'
    ]);

    $xml  = '<?xml version="1.0" encoding="UTF-8"?>';
    $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';

    foreach ($posts as $post) {
        $xml .= '<url>';
        $xml .= '<loc>' . get_permalink($post->ID) . '</loc>';
        $xml .= '<lastmod>' . get_the_modified_date('c', $post) . '</lastmod>';
        $xml .= '</url>';
    }

    $xml .= '</urlset>';

    $file = ABSPATH . 'sitemap.xml';
    file_put_contents($file, $xml);
}
